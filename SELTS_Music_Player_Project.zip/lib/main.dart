
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SELTS Music Player',
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(title: Text("SELTS Music Player")),
        body: Center(child: Text("Welcome to SELTS Music Player")),
      ),
    );
  }
}
