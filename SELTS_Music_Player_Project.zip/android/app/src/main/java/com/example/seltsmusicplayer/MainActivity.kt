
package com.example.seltsmusicplayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
